package za.ac.tut.entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Lob;


@Entity
@Table(name = "ShopALot_TBL")
public class ShopALot implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "fruit_name", nullable = false, length = 100)
    private String fruitName;

    @Column(name = "quantity", nullable = false)
    private int quantity;
   
    @Column(name = "price", nullable = false)
    private Double price;
    
    @Lob
    @Column(name = "image", nullable = true)
    private byte[] image; // This field will store the image as a byte array

    public ShopALot() {
    }

    public ShopALot(Long id, String fruitName, Integer quantity, Double price, byte[] image) {
        this.id = id;
        this.fruitName = fruitName;
        this.quantity = quantity;
        this.price = price;
        this.image = image;
    }

    
     
    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

   

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    // hashCode and equals based on ID for consistency in database identity
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof ShopALot)) {
            return false;
        }
        ShopALot other = (ShopALot) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "za.ac.tut.entities.ShopALot[ id=" + id + ", fruitName=" + fruitName + ", price=" + price+ " ]";
    }
}
